<template functional>
  <path
    fill-rule="nonzero"
    d="M0 .213l15.925 9.77L0 19.79V.213zm2 3.574V16.21l10.106-6.224L2 3.786z"
  />
</template>
